// cpanel - site_templates/countdown_musician/assets/config.js.tt Copyright(c) 2016 cPanel, Inc.
//                                                          All rights Reserved.
// copyright@cpanel.net                                        http://cpanel.net
// This code is subject to the cPanel license. Unauthorized copying is prohibited

window.cpanel = {
    data: {
        email: "",
        logo: "",
        social: [
            
            
            
            
            
            
        ]
    },
    style: {
        primary: "",
    },
    slides: [
        {
            type: 'countdown',
            backgroundImage: "",
            backgroundColor: "#006666",
            color: "",
            buttonText: "",
            buttonLink: "",
            endTime: '2022-12-06T13:17:00.000Z',
            content: "Hallo Dunia\nSelamat Datang SHL",
        }
    ]
};
